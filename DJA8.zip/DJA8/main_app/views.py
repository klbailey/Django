# main_app>views.py
from django.shortcuts import render, redirect, get_object_or_404
from .forms import AddcourseForm
from .models import Addcourse

# Create your views here.  handle render of page and form submission
def add_course(request):
    if request.method == 'POST':
        form = AddcourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.submit = None
            course.save()
            return redirect('add_course_url')  # Redirect to the same page after submission
    else:
        form = AddcourseForm()

    return render(request, 'main_app/index.html', {'form': form, 'courses': Addcourse.objects.all()})   

def remove_course(request, course_id):
    course = get_object_or_404(Addcourse, pk=course_id)
    course.delete()
    return redirect('add_course_url')

def confirm_delete(request, course_id):
    course = get_object_or_404(Addcourse, pk=course_id)
    return render(request, 'main_app/confirm_delete.html', {'course': course})