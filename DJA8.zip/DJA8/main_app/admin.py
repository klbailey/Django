from django.contrib import admin
from main_app.models import Addcourse
# Register your models here.
admin.site.register(Addcourse)