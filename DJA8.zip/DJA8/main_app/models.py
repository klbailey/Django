# main_app>models.py
from django.conf import settings
# in order to use foreign key:
from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class Addcourse(models.Model):
    # define properties (name, description)
    name = models.CharField(max_length = 200)
    description = models.CharField(max_length = 1500)
    # if I want to delete associated course if user is deleted
    # submit = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    submit = models.ForeignKey('auth.User', on_delete=models.CASCADE, null=True, blank=True)
    date_added = models.DateTimeField(auto_now_add=True)

    # method defines human-readable string of an object / returns itself by username
    def __str__(self):
        return self.name