# main_app>urls.py
from django.urls import path
# from . import views
from .views import add_course, remove_course, confirm_delete

urlpatterns = [
    path('', add_course, name='add_course_url'),
    path('remove/<int:course_id>/', remove_course, name='remove_course_url'),
    path('confirm_delete/<int:course_id>/', confirm_delete, name='confirm_delete_url'),
]
