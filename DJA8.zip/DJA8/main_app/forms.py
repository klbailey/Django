# main_app>forms.py
from django import forms
from .models import Addcourse

# display form on a page and handle submissions
class AddcourseForm(forms.ModelForm):
    class Meta:
        model = Addcourse
        fields = ['name', 'description']
