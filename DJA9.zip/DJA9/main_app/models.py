# DJA9>main_app>models.py
from django.conf import settings
from django.db import models
from django.utils import timezone
# in view or model 'reverse' is used to dynamically generate URLS w/in views, models, etc.
from django.urls import reverse

# Create your models here.

# possible actions with a name and URL
class Action(models.Model):
    name = models.CharField(max_length=255)
    url = models.CharField(max_length=255)  # URL for the action

class User(models.Model):
    #define properties of user (id, Full Name, Email, Created At, Actions)
    # AutoField Django automatically creates a unique ID for each user
    user_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(default=timezone.now)
    actions = models.ManyToManyField(Action, related_name='users', blank=True)

# property dynamically calculates the full name based on the first_name and last_name fields.
    # @property
    # def full_name(self):
    #     return f"{self.first_name} {self.last_name}"
    
    # def __str__(self):
    #     return f"{self.first_name} {self.last_name}"
    def __str__(self):
        return f"{self.first_name} {self.last_name}" if self.first_name and self.last_name else self.email

    # method in User model
    def get_absolute_url(self):
        # reverse dynamically generates URL user_detail defined in project urls.py file
        # args=[str(self.id) argument to construct URL includes ID of current user, instance of user (self.id),
        # converted to a string
        return reverse('user_detail', args=[str(self.user_id)])
        