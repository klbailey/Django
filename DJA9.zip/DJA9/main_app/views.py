# DJA9>main_app>views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.http import HttpResponse
from .models import User
from .forms import AddUserForm, EditUserForm

# Create your views here.
class UserDetailView(View):
    template_name = 'main_app/user_detail.html'  # I need to create template

    # Retrieve User instance based on provided user_id and renders template
    def get(self, request, user_id):
        user = get_object_or_404(User, user_id=user_id)
        return render(request, self.template_name, {'user': user})
    
class UserListView(View):
    template_name = 'main_app/index.html'

    def get(self, request):
        users = User.objects.all()
        return render(request, self.template_name, {'users': users})
    
class AddUserView(View):
    template_name = 'main_app/add_user.html'  # Need to create this template

    # triggered when view receives a GET request/handles rendering the initial form page,
    def get(self, request):
        #  This method handles GET requests to the view
        # Render the form page with the empty form
        form = AddUserForm()
        return render(request, self.template_name, {'form': form})

    # triggered when view receives a POST request 
    # handles form submissions, extracts the submitted data, creates a new user in the database, 
    # and redirects the user to the user list view.
    def post(self, request):
        # Process the submitted form
        form = AddUserForm(request.POST)

        if form.is_valid():
            # If the form is valid, save the new user and redirect to the user list view
            new_user = form.save()
            return redirect('user_list')
        else:
            # If the form is not valid, re-render the form page with the errors
            return render(request, self.template_name, {'form': form})
        
class EditUserView(View):
    template_name = 'main_app/edit_user.html'

    def get(self, request, user_id):
        user = get_object_or_404(User, user_id=user_id)
        form = EditUserForm(instance=user)
        return render(request, self.template_name, {'form': form, 'user_id': user_id, 'user': user})

    def post(self, request, user_id):
        user = get_object_or_404(User, user_id=user_id)
        form = EditUserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('user_list')
        else:
            return render(request, self.template_name, {'form': form, 'user_id': user_id, 'user': user})
        #     user = get_object_or_404(User, user_id=user_id)
        #     form = EditUserForm(request.POST, instance=user)
        #     form.save()
        #     return redirect('user_list')
        # else:
        #     return render(request, self.template_name, {'form': form, 'user_id': user_id})
    

class DeleteUserView(View):
    template_name = 'main_app/delete_user.html'  

    def get(self, request, user_id):
        user = get_object_or_404(User, user_id=user_id)
        return render(request, self.template_name, {'user': user})

    def post(self, request, user_id):
        user = get_object_or_404(User, user_id=user_id)
        user.delete()
        return redirect('user_list')