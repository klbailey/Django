from django.contrib import admin
from .models import Action, User

# Register your models here.
admin.site.register(Action)
admin.site.register(User)