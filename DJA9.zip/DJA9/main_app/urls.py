# DJA9>main_app>urls.py
from django.urls import path
from .views import UserDetailView, UserListView, AddUserView, EditUserView, DeleteUserView

urlpatterns = [
    
    path('', UserListView.as_view(), name='user_list'),
    path('users/<int:user_id>/', UserDetailView.as_view(), name='user_detail'),
    path('users/create/', AddUserView.as_view(), name='add_user'),
    path('users/<int:user_id>/edit/', EditUserView.as_view(), name='edit_user'),
    path('users/<int:user_id>/delete/', DeleteUserView.as_view(), name='delete_user'),
]